
from flask import Flask, render_template, request
import pandas as pd
import os

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("file")
    query = request.form.get("query", "")

    if not file:
        return "Файл не выбран"

    path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(path)

    df = pd.read_csv(path)

    if query:
        mask = df.astype(str).apply(
            lambda row: row.str.contains(query, case=False, na=False).any(),
            axis=1
        )
        df = df[mask]

    table = df.head(100).to_html(classes="table table-striped", index=False)

    return render_template(
        "result.html",
        table=table,
        rows=len(df),
        cols=len(df.columns),
        columns=list(df.columns)
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
